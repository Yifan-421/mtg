// API Base URL
const API_BASE_URL = 'https://api.magicthegathering.io/v1/cards';

// DOM Elements
const cardsContainer = document.getElementById('cards-container');
const cardDetails = document.getElementById('card-details');
const deckItems = document.getElementById('deck-items');

// State for the Deck
const deck = [];

// Fetch Cards from API
async function fetchCards() {
    try {
        const response = await fetch(`${API_BASE_URL}?pageSize=10`);
        const data = await response.json();
        displayCards(data.cards);
    } catch (error) {
        console.error('Error fetching:', error);
    }
}

// Display Cards in the Card List Section
function displayCards(cards) {
    cardsContainer.innerHTML = '';
    cards.forEach((card) => {
        const cardElement = document.createElement('div');
        cardElement.className = 'card';
        cardElement.innerHTML = `
            <img src="${card.imageUrl || 'https://via.placeholder.com/150'}" alt="${card.name}">
            <p>${card.name}</p>
        `;
        cardElement.addEventListener('click', () => showCardDetails(card));
        cardsContainer.appendChild(cardElement);
    });
}

// Show Card Details
function showCardDetails(card) {
    cardDetails.innerHTML = `
        <h3>${card.name}</h3>
        <img src="${card.imageUrl || 'https://via.placeholder.com/150'}" alt="${card.name}">
        <p><strong>Type:</strong> ${card.type}</p>
        <p><strong>Mana Cost:</strong> ${card.manaCost || 'N/A'}</p>
        <p><strong>Description:</strong> ${card.text || 'N/A'}</p>
        <button id="add-to-deck">Add to Deck</button>
    `;

    // Add to Deck Button
    document.getElementById('add deck').addEventListener('click', () => addToDeck(card));
}

// Add Card to Deck
function addToDeck(card) {
    if (deck.find((c) => c.id === card.id)) {
        alert('Card is already in the deck.');
        return;
    }
    deck.push(card);
    updateDeckView();
}

// Update Deck View
function updateDeckView() {
    deckItems.innerHTML = '';
    deck.forEach((card, index) => {
        const listItem = document.createElement('li');
        listItem.innerHTML = `
            <span>${card.name}</span>
            <button class="remove-card" data-index="${index}">Remove</button>
        `;
        deckItems.appendChild(listItem);
    });

    // Add Event Listeners to Remove Buttons
    document.querySelectorAll('.remove-card').forEach((button) =>
        button.addEventListener('click', (event) => removeFromDeck(event.target.dataset.index))
    );
}

// Remove Card from Deck
function removeFromDeck(index) {
    deck.splice(index, 1);
    updateDeckView();
}

// Fetch Cards on Page Load
fetchCards();